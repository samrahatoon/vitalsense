# MindConnect Pakistan

## Project Overview
MindConnect Pakistan is a bilingual (Urdu/English) mental health awareness mobile application built with React Native and Expo. The app promotes emotional wellbeing and provides a safe community space for users to track their moods, share thoughts anonymously, and practice relaxation techniques.

## Purpose & Goals
- Promote mental health awareness in Pakistan
- Provide bilingual support (Urdu & English) for accessibility
- Create a safe, anonymous community for emotional support
- Offer practical tools for stress management and mood tracking
- Make mental health resources accessible on mobile devices

## Current State
✅ Fully functional MVP with all core features implemented
✅ Running on Expo web development server (port 5000)
✅ Ready for APK export and mobile deployment

## Project Architecture

### Tech Stack
- **Framework**: React Native with Expo SDK 54
- **Navigation**: React Navigation (Stack & Bottom Tabs)
- **State Management**: React Context API
- **Local Storage**: AsyncStorage
- **UI Components**: React Native core components with Expo Linear Gradient
- **Icons**: Expo Vector Icons (Ionicons)

### Project Structure
```
MindConnectPakistan/
├── src/
│   ├── screens/          # All application screens
│   │   ├── OnboardingScreen.js
│   │   ├── AuthScreen.js
│   │   ├── HomeScreen.js
│   │   ├── FeedScreen.js
│   │   ├── MoodTrackerScreen.js
│   │   ├── RelaxationScreen.js
│   │   └── SettingsScreen.js
│   ├── context/          # Global state management
│   │   └── AppContext.js
│   ├── data/             # Static data and translations
│   │   ├── communityPosts.json
│   │   └── translations.js
│   └── assets/           # Images and audio files
├── App.js                # Main app entry with navigation
├── metro.config.js       # Metro bundler configuration
├── package.json          # Dependencies
└── APK_BUILD_GUIDE.md    # Instructions for exporting APK
```

## Features Implemented

### 1. Onboarding Flow (3 Slides)
- Bilingual welcome messages
- Feature introduction
- Skip and next navigation
- Soft gradient backgrounds (pastel green, sky blue, lavender)

### 2. Authentication
- Email-based login
- Guest mode for anonymous access
- Local data persistence using AsyncStorage

### 3. Home Dashboard
- Personalized greeting based on user
- Today's mood display with emoji and color coding
- Quick access buttons to main features:
  - Post a Thought (links to Mood Tracker)
  - View Community Feed
  - Start Relaxation

### 4. Community Feed
- Anonymous posts in Urdu and English
- Like functionality with heart icon
- Sample mental health posts showcasing:
  - Gratitude expressions
  - Coping strategies
  - Emotional support messages
- Language toggle support

### 5. Relaxation Tools
- **4-7-8 Breathing Exercise**:
  - Animated breathing circle
  - Visual phase indicators (Inhale/Hold/Exhale)
  - 4 seconds inhale → 7 seconds hold → 8 seconds exhale
  - Smooth animations using React Native Animated API
- Instructions in both languages

### 6. Mood Tracker
- Four mood options with emojis:
  - Happy 😊 (Orange)
  - Sad 😢 (Blue)
  - Anxious 😰 (Red)
  - Calm 😌 (Green)
- Visual selection with color coding
- Daily mood saving to AsyncStorage
- Mood history tracking

### 7. Settings
- User profile display (email, guest status)
- Language switcher (English ↔ Urdu)
- Theme toggle (Light/Dark mode)
- Logout functionality
- App version information

### 8. Navigation
- Bottom tab navigation with 5 tabs:
  - Home
  - Feed
  - Mood
  - Relax
  - Settings
- Tab labels in current selected language
- Icons using Ionicons
- Conditional navigation based on auth state

## Design System

### Color Palette
- **Primary Blue**: #3498DB (buttons, accents)
- **Mood Colors**:
  - Happy: #F39C12 (Orange)
  - Sad: #3498DB (Blue)
  - Anxious: #E74C3C (Red)
  - Calm: #27AE60 (Green)
- **Text Colors**:
  - Primary: #2C3E50 (Dark)
  - Secondary: #34495E
  - Muted: #7F8C8D, #95A5A6
- **Backgrounds**:
  - Pastel gradients for each screen
  - White cards with subtle shadows

### UI/UX Features
- Rounded buttons and cards (15-25px border radius)
- Soft drop shadows for depth
- Gradient backgrounds for visual interest
- Emoji-based mood indicators
- Bilingual typography support (Urdu text properly displayed)
- Responsive layout for mobile screens

## Data Management

### AsyncStorage Keys
- `language`: User's preferred language (english/urdu)
- `theme`: UI theme (light/dark)
- `user`: User object with email and guest status
- `hasCompletedOnboarding`: Boolean for first-time experience
- `todayMood`: Current day's mood entry
- `moodHistory`: Array of historical mood entries

### Sample Data
- 8 community posts in `communityPosts.json`
- All UI text translations in `translations.js`
- Organized by feature/screen

## Recent Changes
- **2024-10-24**: Initial project creation
  - Set up Expo project structure
  - Implemented all 7 screens with bilingual support
  - Created global state management with Context API
  - Added navigation with React Navigation
  - Configured Expo web server on port 5000
  - Created APK build documentation

## How to Run

### Development Mode (Web)
The app runs automatically on Replit via the workflow:
```bash
cd MindConnectPakistan && npx expo start --web --port 5000
```

### Testing on Mobile Device
1. Install Expo Go app on your Android/iOS device
2. Scan the QR code shown in the Replit console
3. App will load on your device for testing

### Building APK for Android
See `APK_BUILD_GUIDE.md` for complete instructions on:
- Setting up EAS CLI
- Building APK using Expo's build service
- Installing APK on Android devices
- Publishing to Google Play Store

## Dependencies

### Core
- expo: ~54.0.0
- react: 19.1.0
- react-native: 0.81.5

### Navigation
- @react-navigation/native: Latest
- @react-navigation/bottom-tabs: Latest
- @react-navigation/native-stack: Latest
- react-native-screens: ~4.18.0
- react-native-safe-area-context: Latest

### UI & Utilities
- expo-linear-gradient: Latest
- @expo/vector-icons: Latest
- @react-native-async-storage/async-storage: Latest
- react-dom: 19.1.0 (for web)
- react-native-web: ^0.21.0 (for web)

## User Preferences
- Modern, clean UI with soft colors
- Bilingual support is essential (Urdu & English)
- Anonymous community features for safety
- Simple, intuitive navigation
- Mental health focus with positive messaging

## Future Enhancements (Next Phase)
- Firebase integration for real-time community posts
- User authentication with email verification
- Push notifications for daily mood reminders
- Professional mental health resources directory
- Mood analytics dashboard with charts
- Export mood history as PDF
- In-app chat with mental health professionals
- Crisis helpline quick access
- Meditation audio library
- Journal entry feature

## Deployment Notes
- App runs on Expo's development server during development
- Production builds use EAS Build service
- APK can be distributed directly or via Google Play Store
- Web version accessible via Replit hosting

## Important Files
- `App.js`: Main entry point with navigation setup
- `src/context/AppContext.js`: Global state management
- `src/data/translations.js`: All bilingual text
- `APK_BUILD_GUIDE.md`: APK export instructions
- `metro.config.js`: Metro bundler configuration

## Support & Resources
- Expo Documentation: https://docs.expo.dev/
- React Navigation: https://reactnavigation.org/
- AsyncStorage: https://react-native-async-storage.github.io/async-storage/

---

**Last Updated**: October 24, 2024
**Version**: 1.0.0
**Status**: MVP Complete, Ready for Testing
