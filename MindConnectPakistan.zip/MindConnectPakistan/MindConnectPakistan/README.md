# 🧠 MindConnect Pakistan

A bilingual (Urdu/English) mental health awareness mobile application built with React Native and Expo.

![Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![Expo](https://img.shields.io/badge/Expo-SDK%2054-000020.svg)
![React Native](https://img.shields.io/badge/React%20Native-0.81-61DAFB.svg)

## 📱 About

MindConnect Pakistan promotes mental health awareness and emotional wellbeing through a safe, anonymous community platform. The app provides tools for mood tracking, stress management, and community support—all in both Urdu and English.

## ✨ Features

### 🌟 Core Features
- **Bilingual Support**: Full Urdu and English interface
- **Onboarding**: 3-slide introduction to app features
- **Anonymous Access**: Guest mode for privacy
- **Mood Tracking**: Track daily emotions with 4 mood types
- **Community Feed**: Share and read anonymous mental health posts
- **Breathing Exercises**: 4-7-8 guided breathing technique with animation
- **Settings**: Language toggle, theme switching, and profile management

### 🎨 Design Highlights
- Soft pastel gradient backgrounds
- Rounded buttons and cards
- Clean, modern typography
- Emoji-based mood indicators
- Smooth animations
- Responsive mobile layout

## 🚀 Quick Start

### Prerequisites
- Node.js 20+ installed
- Expo CLI (automatically installed with project)

### Installation

1. **Clone or navigate to the project**
   ```bash
   cd MindConnectPakistan
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Start development server**
   ```bash
   npm start
   ```
   or
   ```bash
   npx expo start
   ```

4. **Run on your device**
   - **Web**: Press `w` in the terminal
   - **Android**: Install Expo Go app and scan QR code
   - **iOS**: Install Expo Go app and scan QR code

## 📂 Project Structure

```
MindConnectPakistan/
├── App.js                    # Main app entry with navigation
├── src/
│   ├── screens/              # All application screens
│   │   ├── OnboardingScreen.js
│   │   ├── AuthScreen.js
│   │   ├── HomeScreen.js
│   │   ├── FeedScreen.js
│   │   ├── MoodTrackerScreen.js
│   │   ├── RelaxationScreen.js
│   │   └── SettingsScreen.js
│   ├── context/
│   │   └── AppContext.js     # Global state management
│   └── data/
│       ├── translations.js   # Bilingual translations
│       └── communityPosts.json
├── package.json
└── APK_BUILD_GUIDE.md       # Instructions for building APK
```

## 🎯 Screen Overview

### 1. Onboarding (3 Slides)
- Welcome message in both languages
- Feature introduction
- Skip or step through option

### 2. Authentication
- Email login
- Guest mode (no registration required)
- Data stored locally with AsyncStorage

### 3. Home Dashboard
- Personalized greeting
- Today's mood display
- Quick access to main features

### 4. Community Feed
- Anonymous posts in Urdu and English
- Like/unlike functionality
- Real mental health support messages

### 5. Mood Tracker
- 4 mood options: Happy, Sad, Anxious, Calm
- Visual selection with color coding
- Daily mood history saved locally

### 6. Relaxation Tools
- **4-7-8 Breathing Exercise**
  - 4 seconds inhale
  - 7 seconds hold
  - 8 seconds exhale
- Animated breathing circle
- Visual phase indicators

### 7. Settings
- Language switcher (English ↔ Urdu)
- Theme toggle (Light/Dark)
- User profile
- Logout option

## 🛠️ Technologies Used

- **Framework**: React Native with Expo SDK 54
- **Navigation**: React Navigation (Stack & Bottom Tabs)
- **State Management**: React Context API
- **Storage**: AsyncStorage for local data persistence
- **UI Components**: 
  - React Native core components
  - Expo Linear Gradient
  - Expo Vector Icons (Ionicons)
- **Animation**: React Native Animated API

## 📱 Building APK for Android

See the comprehensive guide in `APK_BUILD_GUIDE.md` for detailed instructions on:

### Quick Steps:
1. Install EAS CLI
   ```bash
   npm install -g eas-cli
   ```

2. Login to Expo
   ```bash
   eas login
   ```

3. Configure project
   ```bash
   eas build:configure
   ```

4. Build APK
   ```bash
   eas build -p android --profile preview
   ```

5. Download and install the APK on your Android device

## 🌍 Language Support

The app supports full bilingual functionality:

- **English**: Default language
- **Urdu**: Complete Urdu translations with proper RTL text support
- **Toggle**: Switch languages anytime from Settings

All UI elements, including:
- Screen titles
- Button labels
- Community posts
- Instructions
- Alerts and messages

## 💾 Data Storage

Data is stored locally using AsyncStorage:

| Key | Description |
|-----|-------------|
| `language` | User's preferred language |
| `theme` | UI theme (light/dark) |
| `user` | User profile and auth status |
| `hasCompletedOnboarding` | First-time experience flag |
| `todayMood` | Current day's mood entry |
| `moodHistory` | Historical mood entries |

## 🎨 Design System

### Colors
- **Primary**: #3498DB (Blue)
- **Mood Colors**:
  - Happy: #F39C12 (Orange)
  - Sad: #3498DB (Blue)
  - Anxious: #E74C3C (Red)
  - Calm: #27AE60 (Green)

### Typography
- Primary font: System default
- Urdu text: Properly rendered with system fonts
- Font sizes: 12-36px based on hierarchy

## 🤝 Contributing

This is a mental health awareness project for Pakistan. Future enhancements could include:

- Firebase integration for real-time posts
- Push notifications for reminders
- Professional resources directory
- Mood analytics dashboard
- Crisis helpline integration
- Meditation audio library

## 📄 License

This project is open source and available for educational and non-commercial use.

## 🙏 Acknowledgments

- Built to promote mental health awareness in Pakistan
- Designed with cultural sensitivity for Urdu-speaking users
- Inspired by the need for accessible mental health resources

## 📞 Support

For questions or issues, please refer to:
- Expo Documentation: https://docs.expo.dev/
- React Native Documentation: https://reactnavigation.org/

---

**Version**: 1.0.0  
**Built with**: React Native & Expo  
**Purpose**: Mental Health Awareness in Pakistan
