# MindConnect Pakistan - APK Build Guide

This guide will help you export your MindConnect Pakistan app as an APK file using Expo's EAS (Expo Application Services) Build system directly from Replit.

## Prerequisites

Before building your APK, make sure you have:
- A working Expo account (free tier is sufficient)
- Your app running successfully on Replit

## Step 1: Install EAS CLI

In the Replit Shell, run:

```bash
cd MindConnectPakistan
npm install -g eas-cli
```

## Step 2: Login to Your Expo Account

```bash
eas login
```

Enter your Expo account credentials when prompted.

## Step 3: Configure Your Project

Initialize EAS Build configuration:

```bash
eas build:configure
```

This will create an `eas.json` file in your project. The default configuration should work fine for APK builds.

## Step 4: Build Your APK

To build an APK for Android:

```bash
eas build -p android --profile preview
```

**Important Options:**
- `-p android`: Specifies Android platform
- `--profile preview`: Uses the preview profile which generates an APK (instead of AAB for Google Play Store)

### Build Profiles Explained:

- **preview**: Generates APK file (installable directly on Android devices)
- **production**: Generates AAB file (for Google Play Store upload)
- **development**: Generates development build with debugging tools

## Step 5: Monitor Build Progress

After running the build command:
1. EAS will ask you to create a new project (if first time) - press **Y**
2. The build will be queued on Expo's servers
3. You'll see a URL to monitor the build progress
4. The build typically takes 10-20 minutes

Example output:
```
✔ Build finished
✔ APK: https://expo.dev/accounts/[username]/projects/[project]/builds/[build-id]
```

## Step 6: Download Your APK

Once the build completes:
1. Visit the URL provided in your terminal
2. Click "Download" to get your APK file
3. The file will be named something like `build-[build-id].apk`

## Step 7: Install APK on Android Device

### Method 1: Direct Download on Device
1. Open the download link on your Android device
2. Download the APK
3. Open the downloaded file
4. Allow installation from unknown sources if prompted
5. Install the app

### Method 2: Transfer via Computer
1. Download APK to your computer from the Expo dashboard
2. Connect your Android device via USB
3. Transfer the APK file to your device
4. Use a file manager on your device to locate and install the APK

## Alternative: Build for Production (Google Play Store)

If you want to publish to Google Play Store:

```bash
eas build -p android --profile production
```

This generates an AAB (Android App Bundle) file which you can upload to Google Play Console.

## Important Notes

### App Signing
- EAS automatically handles app signing for you
- Your keystore is securely managed by Expo
- You can download your keystore if needed: `eas credentials`

### App Icon & Splash Screen
Before building, make sure to customize:
- **App Icon**: Replace `assets/icon.png` with your 1024x1024 PNG
- **Splash Screen**: Replace `assets/splash-screen.png` with your image
- Update `app.json` with your app details:
  ```json
  {
    "expo": {
      "name": "MindConnect Pakistan",
      "slug": "mindconnect-pakistan",
      "version": "1.0.0",
      "icon": "./assets/icon.png",
      "splash": {
        "image": "./assets/splash-screen.png"
      }
    }
  }
  ```

### Build Configuration (eas.json)

Example `eas.json` for APK builds:

```json
{
  "build": {
    "preview": {
      "android": {
        "buildType": "apk"
      }
    },
    "production": {
      "android": {
        "buildType": "app-bundle"
      }
    },
    "development": {
      "developmentClient": true,
      "distribution": "internal"
    }
  }
}
```

## Troubleshooting

### Build Fails
- Check your `app.json` for any errors
- Ensure all dependencies are properly installed
- Review the build logs on the Expo dashboard

### APK Won't Install
- Enable "Install from Unknown Sources" on your Android device
- Make sure you're downloading the correct APK file
- Check that your device's Android version is compatible (usually Android 5.0+)

### App Crashes on Launch
- Check that all required permissions are set in `app.json`
- Review the error logs using `adb logcat` (if connected to computer)

## Useful Commands

```bash
# Check build status
eas build:list

# View build details
eas build:view [build-id]

# Manage credentials
eas credentials

# Update app version (in app.json) before new build
# Then run build command again
```

## Resources

- [Expo EAS Build Documentation](https://docs.expo.dev/build/introduction/)
- [EAS Build Configuration](https://docs.expo.dev/build/eas-json/)
- [Submitting to Google Play Store](https://docs.expo.dev/submit/android/)

## Next Steps After Building APK

1. **Testing**: Install and test the APK on multiple Android devices
2. **Icon & Branding**: Customize app icon and splash screen
3. **Version Management**: Update version number in `app.json` for each new build
4. **Distribution**: Share APK via link, or prepare for Play Store submission
5. **Updates**: Use Expo Updates (OTA) for quick bug fixes without rebuilding

---

**Note**: Building APKs requires an Expo account but is completely free. EAS Build provides free build credits each month for personal projects.
