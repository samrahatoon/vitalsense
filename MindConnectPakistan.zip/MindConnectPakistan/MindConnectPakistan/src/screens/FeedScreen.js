import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  FlatList,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { AppContext } from '../context/AppContext';
import { translations } from '../data/translations';
import communityPosts from '../data/communityPosts.json';

const FeedScreen = () => {
  const { language } = useContext(AppContext);
  const [posts, setPosts] = useState(
    communityPosts.map(post => ({ ...post, likes: Math.floor(Math.random() * 50) + 5, isLiked: false }))
  );
  const t = translations.feed;

  const handleLike = (postId) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          likes: post.isLiked ? post.likes - 1 : post.likes + 1,
          isLiked: !post.isLiked,
        };
      }
      return post;
    }));
  };

  const getMoodEmoji = (mood) => {
    const emojis = {
      happy: '😊',
      sad: '😢',
      anxious: '😰',
      calm: '😌',
    };
    return emojis[mood] || '🙂';
  };

  const getMoodColor = (mood) => {
    const colors = {
      happy: '#F39C12',
      sad: '#3498DB',
      anxious: '#E74C3C',
      calm: '#27AE60',
    };
    return colors[mood] || '#95A5A6';
  };

  const renderPost = ({ item }) => (
    <View style={styles.postCard}>
      <View style={styles.postHeader}>
        <View style={styles.userInfo}>
          <Ionicons name="person-circle-outline" size={40} color="#95A5A6" />
          <View style={styles.userDetails}>
            <Text style={styles.userName}>{t.anonymous[language]}</Text>
            <Text style={styles.timestamp}>{item.timestamp}</Text>
          </View>
        </View>
        <Text style={styles.moodEmoji}>{getMoodEmoji(item.mood)}</Text>
      </View>

      <Text style={styles.postContent}>
        {item.content[language]}
      </Text>

      <View style={styles.postFooter}>
        <TouchableOpacity
          style={styles.likeButton}
          onPress={() => handleLike(item.id)}
        >
          <Ionicons
            name={item.isLiked ? "heart" : "heart-outline"}
            size={24}
            color={item.isLiked ? "#E74C3C" : "#95A5A6"}
          />
          <Text style={[styles.likeCount, item.isLiked && styles.likeCountActive]}>
            {item.likes}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <LinearGradient colors={['#F3E5F5', '#E1BEE7', '#CE93D8']} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{t.title[language]}</Text>
      </View>
      <FlatList
        data={posts}
        renderItem={renderPost}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
      />
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2C3E50',
  },
  listContent: {
    padding: 20,
    paddingTop: 10,
  },
  postCard: {
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 15,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  postHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  userInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  userDetails: {
    marginLeft: 10,
  },
  userName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#2C3E50',
  },
  timestamp: {
    fontSize: 12,
    color: '#95A5A6',
    marginTop: 2,
  },
  moodEmoji: {
    fontSize: 28,
  },
  postContent: {
    fontSize: 16,
    color: '#34495E',
    lineHeight: 24,
    marginBottom: 15,
  },
  postFooter: {
    borderTopWidth: 1,
    borderTopColor: '#ECF0F1',
    paddingTop: 10,
  },
  likeButton: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  likeCount: {
    marginLeft: 8,
    fontSize: 16,
    color: '#95A5A6',
  },
  likeCountActive: {
    color: '#E74C3C',
    fontWeight: 'bold',
  },
});

export default FeedScreen;
