import React, { useContext } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { AppContext } from '../context/AppContext';
import { translations } from '../data/translations';

const HomeScreen = ({ navigation }) => {
  const { language, user, todayMood } = useContext(AppContext);
  const t = translations.home;
  const moodT = translations.moodTracker;

  const getMoodIcon = (mood) => {
    const icons = {
      happy: '😊',
      sad: '😢',
      anxious: '😰',
      calm: '😌',
    };
    return icons[mood] || '🙂';
  };

  const getMoodColor = (mood) => {
    const colors = {
      happy: '#F39C12',
      sad: '#3498DB',
      anxious: '#E74C3C',
      calm: '#27AE60',
    };
    return colors[mood] || '#95A5A6';
  };

  return (
    <LinearGradient colors={['#E8F5E9', '#B2DFDB', '#81D4FA']} style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <Text style={styles.greeting}>
            {language === 'english' ? 'Hello' : 'السلام علیکم'}
          </Text>
          <Text style={styles.userName}>{user?.isGuest ? 'Guest' : user?.email?.split('@')[0]}</Text>
        </View>

        <View style={styles.moodCard}>
          <Text style={styles.moodCardTitle}>{t.todayMood[language]}</Text>
          {todayMood ? (
            <View style={styles.moodDisplay}>
              <Text style={styles.moodEmoji}>{getMoodIcon(todayMood.mood)}</Text>
              <Text style={[styles.moodText, { color: getMoodColor(todayMood.mood) }]}>
                {moodT[todayMood.mood][language]}
              </Text>
            </View>
          ) : (
            <Text style={styles.noMoodText}>{t.notSet[language]}</Text>
          )}
        </View>

        <View style={styles.questionCard}>
          <Text style={styles.questionText}>{t.greeting[language]}</Text>
        </View>

        <View style={styles.actionsContainer}>
          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: '#9B59B6' }]}
            onPress={() => navigation.navigate('Mood')}
          >
            <Ionicons name="happy-outline" size={32} color="#fff" />
            <Text style={styles.actionButtonText}>{t.postThought[language]}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: '#3498DB' }]}
            onPress={() => navigation.navigate('Feed')}
          >
            <Ionicons name="people-outline" size={32} color="#fff" />
            <Text style={styles.actionButtonText}>{t.viewFeed[language]}</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.actionButton, { backgroundColor: '#27AE60' }]}
            onPress={() => navigation.navigate('Relax')}
          >
            <Ionicons name="leaf-outline" size={32} color="#fff" />
            <Text style={styles.actionButtonText}>{t.startRelaxation[language]}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingTop: 60,
  },
  header: {
    marginBottom: 30,
  },
  greeting: {
    fontSize: 24,
    color: '#34495E',
  },
  userName: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#2C3E50',
    marginTop: 5,
  },
  moodCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 20,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  moodCardTitle: {
    fontSize: 16,
    color: '#7F8C8D',
    marginBottom: 10,
  },
  moodDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  moodEmoji: {
    fontSize: 48,
    marginRight: 15,
  },
  moodText: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  noMoodText: {
    fontSize: 18,
    color: '#95A5A6',
    fontStyle: 'italic',
  },
  questionCard: {
    backgroundColor: '#fff',
    borderRadius: 20,
    padding: 25,
    marginBottom: 30,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  questionText: {
    fontSize: 20,
    color: '#2C3E50',
    textAlign: 'center',
    fontWeight: '600',
  },
  actionsContainer: {
    gap: 15,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
    borderRadius: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 5,
  },
  actionButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 15,
    flex: 1,
  },
});

export default HomeScreen;
