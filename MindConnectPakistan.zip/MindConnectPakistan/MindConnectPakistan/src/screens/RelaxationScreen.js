import React, { useState, useEffect, useContext } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { AppContext } from '../context/AppContext';
import { translations } from '../data/translations';

const RelaxationScreen = () => {
  const { language } = useContext(AppContext);
  const [isBreathing, setIsBreathing] = useState(false);
  const [breathPhase, setBreathPhase] = useState('inhale');
  const [scaleAnim] = useState(new Animated.Value(1));
  const t = translations.relaxation;

  useEffect(() => {
    let interval;
    if (isBreathing) {
      startBreathingCycle();
    } else {
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }).start();
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isBreathing]);

  const startBreathingCycle = () => {
    animateBreath('inhale', 4000, () => {
      animateBreath('hold', 7000, () => {
        animateBreath('exhale', 8000, () => {
          if (isBreathing) {
            startBreathingCycle();
          }
        });
      });
    });
  };

  const animateBreath = (phase, duration, callback) => {
    setBreathPhase(phase);
    const toValue = phase === 'inhale' ? 1.5 : phase === 'hold' ? 1.5 : 1;
    
    Animated.timing(scaleAnim, {
      toValue,
      duration,
      useNativeDriver: true,
    }).start(callback);
  };

  const toggleBreathing = () => {
    setIsBreathing(!isBreathing);
  };

  const getPhaseText = () => {
    return t[breathPhase][language];
  };

  return (
    <LinearGradient colors={['#A8E6CF', '#DCEDC1', '#FFD3B6']} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{t.title[language]}</Text>
      </View>

      <View style={styles.breathingContainer}>
        <Animated.View
          style={[
            styles.breathingCircle,
            {
              transform: [{ scale: scaleAnim }],
            },
          ]}
        >
          <LinearGradient
            colors={['#667eea', '#764ba2']}
            style={styles.circleGradient}
          >
            <Text style={styles.phaseText}>{getPhaseText()}</Text>
          </LinearGradient>
        </Animated.View>
      </View>

      <View style={styles.instructionsContainer}>
        <Text style={styles.instructionsTitle}>4-7-8 {language === 'english' ? 'Method' : 'طریقہ'}</Text>
        <Text style={styles.instructionsText}>
          {language === 'english' 
            ? '• Inhale for 4 seconds\n• Hold for 7 seconds\n• Exhale for 8 seconds'
            : '• 4 سیکنڈ سانس اندر لیں\n• 7 سیکنڈ روکیں\n• 8 سیکنڈ سانس باہر نکالیں'
          }
        </Text>
      </View>

      <View style={styles.buttonContainer}>
        <TouchableOpacity
          style={[styles.controlButton, isBreathing && styles.stopButton]}
          onPress={toggleBreathing}
        >
          <Ionicons
            name={isBreathing ? "stop-circle" : "play-circle"}
            size={24}
            color="#fff"
          />
          <Text style={styles.buttonText}>
            {isBreathing ? t.stopExercise[language] : t.startExercise[language]}
          </Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2C3E50',
    textAlign: 'center',
  },
  breathingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  breathingCircle: {
    width: 200,
    height: 200,
    borderRadius: 100,
  },
  circleGradient: {
    width: '100%',
    height: '100%',
    borderRadius: 100,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#667eea',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 10,
  },
  phaseText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  instructionsContainer: {
    backgroundColor: '#fff',
    marginHorizontal: 20,
    padding: 20,
    borderRadius: 15,
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  instructionsTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2C3E50',
    marginBottom: 10,
    textAlign: 'center',
  },
  instructionsText: {
    fontSize: 16,
    color: '#34495E',
    lineHeight: 28,
  },
  buttonContainer: {
    paddingHorizontal: 20,
    paddingBottom: 40,
  },
  controlButton: {
    backgroundColor: '#27AE60',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 18,
    borderRadius: 25,
    shadowColor: '#27AE60',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
  stopButton: {
    backgroundColor: '#E74C3C',
    shadowColor: '#E74C3C',
  },
  buttonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 10,
  },
});

export default RelaxationScreen;
