import React, { useState, useContext, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { AppContext } from '../context/AppContext';
import { translations } from '../data/translations';

const { width, height } = Dimensions.get('window');

const OnboardingScreen = ({ navigation }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const { language, completeOnboarding } = useContext(AppContext);
  const scrollViewRef = useRef(null);

  const slides = [
    {
      key: 'slide1',
      gradient: ['#E8F5E9', '#B2DFDB', '#81D4FA'],
    },
    {
      key: 'slide2',
      gradient: ['#F3E5F5', '#CE93D8', '#B39DDB'],
    },
    {
      key: 'slide3',
      gradient: ['#FFF9C4', '#FFE082', '#FFAB91'],
    },
  ];

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      const nextSlide = currentSlide + 1;
      setCurrentSlide(nextSlide);
      scrollViewRef.current?.scrollTo({ x: width * nextSlide, animated: true });
    } else {
      handleGetStarted();
    }
  };

  const handleSkip = () => {
    handleGetStarted();
  };

  const handleGetStarted = async () => {
    await completeOnboarding();
    navigation.replace('Auth');
  };

  const renderSlide = (slide, index) => {
    const slideData = translations.onboarding[slide.key][language];
    
    return (
      <View key={slide.key} style={styles.slide}>
        <LinearGradient colors={slide.gradient} style={styles.gradient}>
          <View style={styles.slideContent}>
            <Text style={styles.slideTitle}>{slideData.title}</Text>
            <Text style={styles.slideDescription}>
              {slideData.description || slideData.subtitle}
            </Text>
            {slide.key === 'slide1' && (
              <Text style={[styles.slideDescription, styles.urduText]}>
                {slideData.urduSubtitle}
              </Text>
            )}
          </View>
        </LinearGradient>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        scrollEnabled={false}
        style={styles.scrollView}
      >
        {slides.map((slide, index) => renderSlide(slide, index))}
      </ScrollView>

      <View style={styles.footer}>
        <View style={styles.pagination}>
          {slides.map((_, index) => (
            <View
              key={index}
              style={[
                styles.paginationDot,
                currentSlide === index && styles.paginationDotActive,
              ]}
            />
          ))}
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={handleSkip} style={styles.skipButton}>
            <Text style={styles.skipButtonText}>
              {translations.onboarding.skip[language]}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={handleNext} style={styles.nextButton}>
            <Text style={styles.nextButtonText}>
              {currentSlide === slides.length - 1
                ? translations.onboarding.getStarted[language]
                : translations.onboarding.next[language]}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  scrollView: {
    flex: 1,
  },
  slide: {
    width: width,
    height: height,
  },
  gradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  slideContent: {
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  slideTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#2C3E50',
    textAlign: 'center',
    marginBottom: 20,
  },
  slideDescription: {
    fontSize: 18,
    color: '#34495E',
    textAlign: 'center',
    lineHeight: 26,
    marginTop: 10,
  },
  urduText: {
    fontSize: 20,
    fontWeight: '600',
    marginTop: 15,
  },
  footer: {
    position: 'absolute',
    bottom: 50,
    left: 0,
    right: 0,
    paddingHorizontal: 30,
  },
  pagination: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 30,
  },
  paginationDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#BDC3C7',
    marginHorizontal: 5,
  },
  paginationDotActive: {
    width: 30,
    backgroundColor: '#3498DB',
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  skipButton: {
    padding: 15,
  },
  skipButtonText: {
    fontSize: 16,
    color: '#7F8C8D',
  },
  nextButton: {
    backgroundColor: '#3498DB',
    paddingHorizontal: 30,
    paddingVertical: 15,
    borderRadius: 25,
  },
  nextButtonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#fff',
  },
});

export default OnboardingScreen;
