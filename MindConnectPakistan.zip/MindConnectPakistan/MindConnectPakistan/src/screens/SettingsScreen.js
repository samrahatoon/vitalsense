import React, { useContext } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Switch,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { AppContext } from '../context/AppContext';
import { translations } from '../data/translations';

const SettingsScreen = ({ navigation }) => {
  const { language, theme, user, toggleLanguage, toggleTheme, logout } = useContext(AppContext);
  const t = translations.settings;

  const handleLogout = () => {
    Alert.alert(
      language === 'english' ? 'Logout' : 'لاگ آؤٹ',
      language === 'english' ? 'Are you sure you want to logout?' : 'کیا آپ واقعی لاگ آؤٹ کرنا چاہتے ہیں؟',
      [
        {
          text: language === 'english' ? 'Cancel' : 'منسوخ',
          style: 'cancel',
        },
        {
          text: language === 'english' ? 'Logout' : 'لاگ آؤٹ',
          onPress: async () => {
            await logout();
            navigation.replace('Auth');
          },
          style: 'destructive',
        },
      ]
    );
  };

  return (
    <LinearGradient colors={['#E8F5E9', '#B2DFDB', '#81D4FA']} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{t.title[language]}</Text>
      </View>

      <View style={styles.content}>
        <View style={styles.section}>
          <View style={styles.userCard}>
            <Ionicons name="person-circle" size={60} color="#3498DB" />
            <View style={styles.userInfo}>
              <Text style={styles.userEmail}>{user?.email}</Text>
              <Text style={styles.userType}>
                {user?.isGuest 
                  ? (language === 'english' ? 'Guest User' : 'مہمان صارف')
                  : (language === 'english' ? 'Member' : 'رکن')
                }
              </Text>
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <View style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Ionicons name="language" size={24} color="#3498DB" />
              <Text style={styles.settingLabel}>{t.language[language]}</Text>
            </View>
            <TouchableOpacity style={styles.languageButton} onPress={toggleLanguage}>
              <Text style={styles.languageButtonText}>
                {language === 'english' ? 'English / اردو' : 'اردو / English'}
              </Text>
            </TouchableOpacity>
          </View>

          <View style={styles.settingItem}>
            <View style={styles.settingLeft}>
              <Ionicons name={theme === 'light' ? 'sunny' : 'moon'} size={24} color="#3498DB" />
              <Text style={styles.settingLabel}>{t.theme[language]}</Text>
            </View>
            <View style={styles.themeToggle}>
              <Text style={styles.themeText}>
                {theme === 'light' ? t.light[language] : t.dark[language]}
              </Text>
              <Switch
                value={theme === 'dark'}
                onValueChange={toggleTheme}
                trackColor={{ false: '#BDC3C7', true: '#3498DB' }}
                thumbColor={theme === 'dark' ? '#2C3E50' : '#ECF0F1'}
              />
            </View>
          </View>
        </View>

        <View style={styles.section}>
          <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
            <Ionicons name="log-out-outline" size={24} color="#E74C3C" />
            <Text style={styles.logoutText}>{t.logout[language]}</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.footer}>
          <Text style={styles.footerText}>
            MindConnect Pakistan v1.0
          </Text>
          <Text style={styles.footerSubtext}>
            {language === 'english' 
              ? 'Promoting mental health awareness'
              : 'ذہنی صحت کی آگاہی کو فروغ دینا'
            }
          </Text>
        </View>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2C3E50',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  section: {
    marginBottom: 20,
  },
  userCard: {
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  userInfo: {
    marginLeft: 15,
    flex: 1,
  },
  userEmail: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2C3E50',
  },
  userType: {
    fontSize: 14,
    color: '#7F8C8D',
    marginTop: 5,
  },
  settingItem: {
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingLabel: {
    fontSize: 16,
    fontWeight: '600',
    color: '#2C3E50',
    marginLeft: 15,
  },
  languageButton: {
    backgroundColor: '#3498DB',
    paddingHorizontal: 15,
    paddingVertical: 8,
    borderRadius: 20,
  },
  languageButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  themeToggle: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  themeText: {
    fontSize: 14,
    color: '#7F8C8D',
    marginRight: 10,
  },
  logoutButton: {
    backgroundColor: '#fff',
    borderRadius: 15,
    padding: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 5,
  },
  logoutText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#E74C3C',
    marginLeft: 10,
  },
  footer: {
    alignItems: 'center',
    marginTop: 30,
  },
  footerText: {
    fontSize: 14,
    color: '#7F8C8D',
  },
  footerSubtext: {
    fontSize: 12,
    color: '#95A5A6',
    marginTop: 5,
  },
});

export default SettingsScreen;
