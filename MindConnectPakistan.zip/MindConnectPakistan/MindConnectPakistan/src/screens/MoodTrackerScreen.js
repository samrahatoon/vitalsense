import React, { useState, useContext } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { AppContext } from '../context/AppContext';
import { translations } from '../data/translations';

const MoodTrackerScreen = () => {
  const { language, saveMood, todayMood } = useContext(AppContext);
  const [selectedMood, setSelectedMood] = useState(todayMood?.mood || null);
  const t = translations.moodTracker;

  const moods = [
    { id: 'happy', emoji: '😊', color: '#F39C12' },
    { id: 'sad', emoji: '😢', color: '#3498DB' },
    { id: 'anxious', emoji: '😰', color: '#E74C3C' },
    { id: 'calm', emoji: '😌', color: '#27AE60' },
  ];

  const handleSaveMood = async () => {
    if (!selectedMood) {
      Alert.alert(
        language === 'english' ? 'Select Mood' : 'موڈ منتخب کریں',
        language === 'english' ? 'Please select a mood first' : 'پہلے موڈ منتخب کریں'
      );
      return;
    }

    await saveMood(selectedMood);
    Alert.alert(
      language === 'english' ? 'Success' : 'کامیاب',
      t.moodSaved[language]
    );
  };

  return (
    <LinearGradient colors={['#FFF9C4', '#FFE082', '#FFAB91']} style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>{t.title[language]}</Text>
        <Text style={styles.subtitle}>{t.selectMood[language]}</Text>
      </View>

      <View style={styles.moodsContainer}>
        {moods.map((mood) => (
          <TouchableOpacity
            key={mood.id}
            style={[
              styles.moodButton,
              selectedMood === mood.id && { 
                backgroundColor: mood.color,
                transform: [{ scale: 1.1 }],
              },
            ]}
            onPress={() => setSelectedMood(mood.id)}
          >
            <Text style={styles.moodEmoji}>{mood.emoji}</Text>
            <Text
              style={[
                styles.moodLabel,
                selectedMood === mood.id && styles.moodLabelSelected,
              ]}
            >
              {t[mood.id][language]}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      <View style={styles.bottomContainer}>
        <TouchableOpacity
          style={styles.saveButton}
          onPress={handleSaveMood}
        >
          <Text style={styles.saveButtonText}>{t.saveMood[language]}</Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingTop: 60,
    paddingBottom: 30,
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#2C3E50',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#34495E',
    textAlign: 'center',
  },
  moodsContainer: {
    flex: 1,
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
    gap: 20,
  },
  moodButton: {
    width: 150,
    height: 150,
    backgroundColor: '#fff',
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  moodEmoji: {
    fontSize: 60,
    marginBottom: 10,
  },
  moodLabel: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#2C3E50',
  },
  moodLabelSelected: {
    color: '#fff',
  },
  bottomContainer: {
    padding: 20,
    paddingBottom: 40,
  },
  saveButton: {
    backgroundColor: '#3498DB',
    paddingVertical: 18,
    borderRadius: 25,
    alignItems: 'center',
    shadowColor: '#3498DB',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 5,
  },
  saveButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default MoodTrackerScreen;
