export const translations = {
  onboarding: {
    slide1: {
      english: {
        title: "Welcome to MindConnect",
        subtitle: "Your mental peace is our mission",
        urduSubtitle: "آپ کا ذہنی سکون ہمارا مقصد"
      },
      urdu: {
        title: "MindConnect میں خوش آمدید",
        subtitle: "آپ کا ذہنی سکون ہمارا مقصد",
        urduSubtitle: "Your mental peace is our mission"
      }
    },
    slide2: {
      english: {
        title: "Track & Share",
        description: "Track your mood, read calming posts, and share your thoughts anonymously."
      },
      urdu: {
        title: "ٹریک اور شیئر کریں",
        description: "اپنے موڈ کو ٹریک کریں، پرسکون پوسٹس پڑھیں، اور گمنام طور پر اپنے خیالات شیئر کریں۔"
      }
    },
    slide3: {
      english: {
        title: "Safe Community",
        description: "Join a safe Urdu-English community that supports emotional wellbeing."
      },
      urdu: {
        title: "محفوظ کمیونٹی",
        description: "ایک محفوظ اردو-انگلش کمیونٹی میں شامل ہوں جو جذباتی بہبود کی حمایت کرتی ہے۔"
      }
    },
    skip: {
      english: "Skip",
      urdu: "چھوڑیں"
    },
    next: {
      english: "Next",
      urdu: "اگلا"
    },
    getStarted: {
      english: "Get Started",
      urdu: "شروع کریں"
    }
  },
  auth: {
    title: {
      english: "Welcome Back",
      urdu: "خوش آمدید"
    },
    email: {
      english: "Email",
      urdu: "ای میل"
    },
    password: {
      english: "Password",
      urdu: "پاس ورڈ"
    },
    login: {
      english: "Login",
      urdu: "لاگ ان"
    },
    guestMode: {
      english: "Continue as Guest",
      urdu: "مہمان کے طور پر جاری رکھیں"
    },
    signup: {
      english: "Don't have an account? Sign Up",
      urdu: "اکاؤنٹ نہیں ہے؟ سائن اپ کریں"
    }
  },
  home: {
    greeting: {
      english: "How are you feeling today?",
      urdu: "آج آپ کیسا محسوس کر رہے ہیں؟"
    },
    postThought: {
      english: "Post a Thought",
      urdu: "خیال شیئر کریں"
    },
    viewFeed: {
      english: "View Community Feed",
      urdu: "کمیونٹی فیڈ دیکھیں"
    },
    startRelaxation: {
      english: "Start Relaxation",
      urdu: "آرام شروع کریں"
    },
    todayMood: {
      english: "Today's Mood",
      urdu: "آج کا موڈ"
    },
    notSet: {
      english: "Not set yet",
      urdu: "ابھی سیٹ نہیں"
    }
  },
  feed: {
    title: {
      english: "Community Feed",
      urdu: "کمیونٹی فیڈ"
    },
    anonymous: {
      english: "Anonymous",
      urdu: "گمنام"
    }
  },
  relaxation: {
    title: {
      english: "Breathing Exercise",
      urdu: "سانس لینے کی مشق"
    },
    inhale: {
      english: "Inhale",
      urdu: "سانس اندر"
    },
    hold: {
      english: "Hold",
      urdu: "روکیں"
    },
    exhale: {
      english: "Exhale",
      urdu: "سانس باہر"
    },
    startExercise: {
      english: "Start Exercise",
      urdu: "مشق شروع کریں"
    },
    stopExercise: {
      english: "Stop Exercise",
      urdu: "مشق بند کریں"
    },
    playMusic: {
      english: "Play Calming Music",
      urdu: "پرسکون موسیقی چلائیں"
    },
    stopMusic: {
      english: "Stop Music",
      urdu: "موسیقی بند کریں"
    }
  },
  moodTracker: {
    title: {
      english: "How are you feeling?",
      urdu: "آپ کیسا محسوس کر رہے ہیں؟"
    },
    selectMood: {
      english: "Select your mood",
      urdu: "اپنا موڈ منتخب کریں"
    },
    happy: {
      english: "Happy",
      urdu: "خوش"
    },
    sad: {
      english: "Sad",
      urdu: "اداس"
    },
    anxious: {
      english: "Anxious",
      urdu: "فکرمند"
    },
    calm: {
      english: "Calm",
      urdu: "پرسکون"
    },
    saveMood: {
      english: "Save Mood",
      urdu: "موڈ محفوظ کریں"
    },
    moodSaved: {
      english: "Mood saved successfully!",
      urdu: "موڈ کامیابی سے محفوظ ہو گیا!"
    }
  },
  settings: {
    title: {
      english: "Settings",
      urdu: "ترتیبات"
    },
    language: {
      english: "Language",
      urdu: "زبان"
    },
    theme: {
      english: "Theme",
      urdu: "تھیم"
    },
    light: {
      english: "Light",
      urdu: "روشن"
    },
    dark: {
      english: "Dark",
      urdu: "تاریک"
    },
    logout: {
      english: "Logout",
      urdu: "لاگ آؤٹ"
    }
  },
  tabs: {
    home: {
      english: "Home",
      urdu: "ہوم"
    },
    feed: {
      english: "Feed",
      urdu: "فیڈ"
    },
    mood: {
      english: "Mood",
      urdu: "موڈ"
    },
    relax: {
      english: "Relax",
      urdu: "آرام"
    },
    settings: {
      english: "Settings",
      urdu: "ترتیبات"
    }
  }
};

export const getTranslation = (path, language) => {
  const keys = path.split('.');
  let value = translations;
  
  for (const key of keys) {
    value = value[key];
    if (!value) return '';
  }
  
  return value[language] || value.english;
};
