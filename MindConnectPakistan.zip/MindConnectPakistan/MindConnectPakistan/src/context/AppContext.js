import React, { createContext, useState, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

export const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [language, setLanguage] = useState('english');
  const [theme, setTheme] = useState('light');
  const [user, setUser] = useState(null);
  const [hasCompletedOnboarding, setHasCompletedOnboarding] = useState(false);
  const [todayMood, setTodayMood] = useState(null);
  const [moodHistory, setMoodHistory] = useState([]);

  useEffect(() => {
    loadAppData();
  }, []);

  const loadAppData = async () => {
    try {
      const savedLanguage = await AsyncStorage.getItem('language');
      const savedTheme = await AsyncStorage.getItem('theme');
      const savedUser = await AsyncStorage.getItem('user');
      const onboardingStatus = await AsyncStorage.getItem('hasCompletedOnboarding');
      const savedMood = await AsyncStorage.getItem('todayMood');
      const savedMoodHistory = await AsyncStorage.getItem('moodHistory');

      if (savedLanguage) setLanguage(savedLanguage);
      if (savedTheme) setTheme(savedTheme);
      if (savedUser) setUser(JSON.parse(savedUser));
      if (onboardingStatus) setHasCompletedOnboarding(JSON.parse(onboardingStatus));
      if (savedMood) setTodayMood(JSON.parse(savedMood));
      if (savedMoodHistory) setMoodHistory(JSON.parse(savedMoodHistory));
    } catch (error) {
      console.log('Error loading app data:', error);
    }
  };

  const toggleLanguage = async () => {
    const newLanguage = language === 'english' ? 'urdu' : 'english';
    setLanguage(newLanguage);
    await AsyncStorage.setItem('language', newLanguage);
  };

  const toggleTheme = async () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    await AsyncStorage.setItem('theme', newTheme);
  };

  const saveUser = async (userData) => {
    setUser(userData);
    await AsyncStorage.setItem('user', JSON.stringify(userData));
  };

  const completeOnboarding = async () => {
    setHasCompletedOnboarding(true);
    await AsyncStorage.setItem('hasCompletedOnboarding', JSON.stringify(true));
  };

  const saveMood = async (mood) => {
    const today = new Date().toISOString().split('T')[0];
    const moodEntry = { mood, date: today };
    
    setTodayMood(moodEntry);
    await AsyncStorage.setItem('todayMood', JSON.stringify(moodEntry));

    const updatedHistory = [...moodHistory.filter(m => m.date !== today), moodEntry];
    setMoodHistory(updatedHistory);
    await AsyncStorage.setItem('moodHistory', JSON.stringify(updatedHistory));
  };

  const logout = async () => {
    setUser(null);
    await AsyncStorage.removeItem('user');
  };

  return (
    <AppContext.Provider
      value={{
        language,
        theme,
        user,
        hasCompletedOnboarding,
        todayMood,
        moodHistory,
        toggleLanguage,
        toggleTheme,
        saveUser,
        completeOnboarding,
        saveMood,
        logout,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
